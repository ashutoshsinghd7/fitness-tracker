"""Natural-language meal parsing via the Claude API (tool-use forces structured JSON out)."""
import os
from functools import lru_cache

from fastapi import HTTPException

EXTRACT_TOOL = {
    "name": "extract_food_items",
    "description": "Extract each distinct food or dish and its serving count from a free-text meal description.",
    "input_schema": {
        "type": "object",
        "properties": {
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "food_name": {"type": "string",
                                      "description": "Plain dish name, e.g. 'roti', 'aloo gobi', 'moong dal'"},
                        "quantity": {"type": "number",
                                     "description": "Serving count, e.g. 2 for '2 rotis', 1 for 'a bowl of dal'"},
                    },
                    "required": ["food_name", "quantity"],
                },
            }
        },
        "required": ["items"],
    },
}

@lru_cache
def _client():
    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise HTTPException(503, "ANTHROPIC_API_KEY is not set on the backend — quick-log is disabled.")
    import anthropic
    return anthropic.Anthropic()

def parse_meal_text(text: str) -> list[dict]:
    resp = _client().messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=1024,
        tools=[EXTRACT_TOOL],
        tool_choice={"type": "tool", "name": "extract_food_items"},
        messages=[{"role": "user", "content": f'Extract the food items and quantities from: "{text}"'}],
    )
    block = next(b for b in resp.content if b.type == "tool_use")
    return block.input["items"]
