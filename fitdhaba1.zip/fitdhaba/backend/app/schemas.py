"""Pydantic request/response models."""
from pydantic import BaseModel

class ProfileIn(BaseModel):
    user_id: str = "default"
    age: int
    gender: str
    weight: float
    height: float
    activity: str
    goal: str
    condition: str = "none"

class LogIn(BaseModel):
    user_id: str = "default"
    food_id: int
    qty: float = 1.0
    meal: str = "snack"

class NaturalLogIn(BaseModel):
    user_id: str = "default"
    text: str
