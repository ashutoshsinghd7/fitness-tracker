"""FitDhaba API — pure JSON backend, no static file serving. Frontend lives in /frontend."""
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import init_db
from .routers import foods, logs, profile

load_dotenv()
init_db()

app = FastAPI(title="FitDhaba API", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(profile.router)
app.include_router(foods.router)
app.include_router(logs.router)

@app.get("/")
def health():
    return {"status": "ok", "service": "FitDhaba API"}
