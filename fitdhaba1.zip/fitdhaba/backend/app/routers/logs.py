"""Food logging, daily summary + suggestions, history."""
import os
from datetime import date, datetime, timedelta

from fastapi import APIRouter, HTTPException

from ..database import get_db
from ..foods_data import FOODS, FOODS_BY_ID, find_matches
from ..local_nlp import parse_meal_text_local
from ..nlp import parse_meal_text
from ..schemas import LogIn, NaturalLogIn

router = APIRouter(prefix="/api", tags=["logs"])

NUTRIENTS = ["calories", "protein", "carbs", "fat", "fiber", "sodium", "calcium", "iron"]

def _day_totals(user_id: str, day: str):
    rows = get_db().execute(
        "SELECT * FROM logs WHERE user_id=? AND date(logged_at)=?", (user_id, day)).fetchall()
    totals = {n: 0.0 for n in NUTRIENTS}
    for r in rows:
        for n in NUTRIENTS:
            totals[n] += r[n]
    return totals, [dict(r) for r in rows]

def _suggest_foods(remaining_cal: float, gap_nutrient: str):
    if remaining_cal <= 20:
        return []
    pool = [f for f in FOODS if 0 < f["calories"] <= remaining_cal * 1.3]
    pool.sort(key=lambda f: f[gap_nutrient] / f["calories"], reverse=True)
    return [{"id": f["id"], "name": f["name"], "calories": f["calories"],
              gap_nutrient: f[gap_nutrient], "source": f["source"]} for f in pool[:5]]

@router.post("/log/parse")
def parse_log(entry: NaturalLogIn):
    """Turn a free-text meal description into candidate food matches for the user to confirm.
    Uses Claude if ANTHROPIC_API_KEY is set (better at messy phrasing); otherwise falls back
    to a free local rule-based parser, no API key required."""
    used_ai = False
    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            items = parse_meal_text(entry.text)
            used_ai = True
        except Exception:
            items = parse_meal_text_local(entry.text)
    else:
        items = parse_meal_text_local(entry.text)
    return {
        "used_ai": used_ai,
        "items": [
            {"food_name": it["food_name"], "quantity": it.get("quantity", 1),
             "matches": find_matches(it["food_name"])}
            for it in items
        ],
    }

@router.post("/log")
def log_food(entry: LogIn):
    food = FOODS_BY_ID.get(entry.food_id)
    if not food:
        raise HTTPException(404, "Food not found")
    if not get_db().execute("SELECT 1 FROM profile WHERE user_id=?", (entry.user_id,)).fetchone():
        raise HTTPException(400, "Set up your profile first")
    qty = entry.qty
    with get_db() as con:
        con.execute("""INSERT INTO logs
            (user_id,food_id,food_name,qty,meal,calories,protein,carbs,fat,fiber,sodium,calcium,iron,logged_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (entry.user_id, food["id"], food["name"], qty, entry.meal,
             food["calories"] * qty, food["protein"] * qty, food["carbs"] * qty, food["fat"] * qty,
             food["fiber"] * qty, food["sodium"] * qty, food["calcium"] * qty, food["iron"] * qty,
             datetime.now().isoformat()))
    return today_summary(entry.user_id)

@router.delete("/log/{log_id}")
def delete_log(log_id: int, user_id: str = "default"):
    with get_db() as con:
        con.execute("DELETE FROM logs WHERE id=? AND user_id=?", (log_id, user_id))
    return today_summary(user_id)

@router.get("/today")
def today_summary(user_id: str = "default"):
    profile = get_db().execute("SELECT * FROM profile WHERE user_id=?", (user_id,)).fetchone()
    if not profile:
        raise HTTPException(404, "Set up your profile first")
    today = date.today().isoformat()
    totals, entries = _day_totals(user_id, today)

    remaining_cal = profile["target_cal"] - totals["calories"]
    gaps = {
        "protein": profile["target_protein"] - totals["protein"],
        "calcium": profile["target_calcium"] - totals["calcium"],
        "iron": profile["target_iron"] - totals["iron"],
    }
    gap_nutrient = max(gaps, key=gaps.get) if max(gaps.values()) > 0 else "protein"

    tips = []
    if totals["protein"] < profile["target_protein"] * 0.7:
        tips.append("Protein is behind target — add dal, paneer, curd, or eggs.")
    if totals["calcium"] < profile["target_calcium"] * 0.5:
        tips.append("Calcium intake is low — try buttermilk, curd, or sesame seeds.")
    if totals["iron"] < profile["target_iron"] * 0.5:
        tips.append("Iron is low — add spinach, jaggery, or fortified roti.")
    if totals["sodium"] > profile["target_sodium"]:
        tips.append("Sodium is over your limit today — go easy on pickles and packaged snacks.")
    if not tips:
        tips.append("You're on track — nice balance today!")

    return {
        "targets": dict(profile),
        "consumed": {k: round(v, 1) for k, v in totals.items()},
        "remaining_calories": round(remaining_cal, 1),
        "entries": entries,
        "tips": tips,
        "suggestions": _suggest_foods(remaining_cal, gap_nutrient),
    }

@router.get("/history")
def history(user_id: str = "default", days: int = 7):
    out = []
    for i in range(days - 1, -1, -1):
        d = (date.today() - timedelta(days=i)).isoformat()
        totals, _ = _day_totals(user_id, d)
        out.append({"date": d, **{k: round(v, 1) for k, v in totals.items()}})
    return out
