"""Food database search."""
from fastapi import APIRouter

from ..foods_data import FOODS

router = APIRouter(prefix="/api/foods", tags=["foods"])

@router.get("")
def search_foods(q: str = "", limit: int = 25):
    q = q.strip().lower()
    results = [f for f in FOODS if q in f["name"].lower()] if q else FOODS[:limit]
    return results[:limit]
