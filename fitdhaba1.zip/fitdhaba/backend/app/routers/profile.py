"""Profile setup + target calculation."""
from fastapi import APIRouter, HTTPException

from ..database import get_db
from ..nutrition import compute_targets
from ..schemas import ProfileIn

router = APIRouter(prefix="/api/profile", tags=["profile"])

@router.post("")
def set_profile(p: ProfileIn):
    t = compute_targets(p.age, p.gender, p.weight, p.height, p.activity, p.goal, p.condition)
    with get_db() as con:
        con.execute("""INSERT INTO profile VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(user_id) DO UPDATE SET
            age=excluded.age, gender=excluded.gender, weight=excluded.weight, height=excluded.height,
            activity=excluded.activity, goal=excluded.goal, condition=excluded.condition,
            target_cal=excluded.target_cal, target_protein=excluded.target_protein,
            target_carb=excluded.target_carb, target_fat=excluded.target_fat,
            target_sodium=excluded.target_sodium, target_calcium=excluded.target_calcium,
            target_iron=excluded.target_iron""",
            (p.user_id, p.age, p.gender, p.weight, p.height, p.activity, p.goal, p.condition,
             t["target_cal"], t["target_protein"], t["target_carb"], t["target_fat"],
             t["target_sodium"], t["target_calcium"], t["target_iron"]))
    return {"ok": True, "targets": t}

@router.get("")
def get_profile(user_id: str = "default"):
    row = get_db().execute("SELECT * FROM profile WHERE user_id=?", (user_id,)).fetchone()
    if not row:
        raise HTTPException(404, "No profile set up yet")
    return dict(row)
