"""BMR/TDEE + macro target rules, adjusted for goal and health condition."""

ACTIVITY = {"sedentary": 1.2, "light": 1.375, "moderate": 1.55, "active": 1.725, "athlete": 1.9}

GOAL_CAL_ADJUST = {
    "weight_loss": -500,
    "muscle_gain": 300,
    "athletic_performance": 200,
    "general_health": 0,
    "manage_condition": 0,
}

# condition -> (protein%, carb%, fat%, sodium_cap_mg)
CONDITION_MACROS = {
    "none": (0.30, 0.45, 0.25, 2300),
    "diabetes": (0.30, 0.35, 0.35, 2300),
    "pcos": (0.35, 0.35, 0.30, 2300),
    "thyroid": (0.30, 0.40, 0.30, 2300),
    "hypertension": (0.25, 0.50, 0.25, 1500),
    "kidney_disease": (0.15, 0.55, 0.30, 1500),
    "celiac": (0.30, 0.45, 0.25, 2300),
    "ibs": (0.25, 0.50, 0.25, 2300),
    "anemia": (0.30, 0.45, 0.25, 2300),
    "heart_disease": (0.25, 0.50, 0.25, 1500),
}

def compute_targets(age, gender, weight, height, activity, goal, condition) -> dict:
    bmr = 10 * weight + 6.25 * height - 5 * age + (5 if gender == "male" else -161)
    tdee = bmr * ACTIVITY.get(activity, 1.375)
    target_cal = max(1200, tdee + GOAL_CAL_ADJUST.get(goal, 0))
    p_pct, c_pct, f_pct, sodium_cap = CONDITION_MACROS.get(condition, CONDITION_MACROS["none"])
    return dict(
        target_cal=round(target_cal),
        target_protein=round(target_cal * p_pct / 4),
        target_carb=round(target_cal * c_pct / 4),
        target_fat=round(target_cal * f_pct / 9),
        target_sodium=sodium_cap,
        target_calcium=1000,
        target_iron=18 if gender == "female" else 8,
    )
