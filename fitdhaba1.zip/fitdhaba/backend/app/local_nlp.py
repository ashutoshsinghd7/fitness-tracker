"""Free, no-API fallback: rule-based extraction of food items + quantities from free text."""
import re

NUMBER_WORDS = {
    "a": 1, "an": 1, "one": 1, "single": 1,
    "two": 2, "couple": 2, "pair": 2,
    "three": 3, "few": 3,
    "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
}
FILLER_WORDS = {"bowl", "bowls", "cup", "cups", "plate", "plates", "glass", "glasses",
                 "piece", "pieces", "serving", "servings", "spoon", "spoons",
                 "tbsp", "tsp", "of", "some"}

def _segments(text: str) -> list[str]:
    text = re.sub(r"\band\b", ",", text, flags=re.I)
    return [s.strip() for s in text.split(",") if s.strip()]

def _extract(segment: str) -> tuple[float, str]:
    words = segment.split()
    qty, i = 1.0, 0
    if words and re.fullmatch(r"\d+(\.\d+)?", words[0]):
        qty, i = float(words[0]), 1
    elif words and words[0].lower() in NUMBER_WORDS:
        qty, i = float(NUMBER_WORDS[words[0].lower()]), 1
    while i < len(words) and words[i].lower() in FILLER_WORDS:
        i += 1
    name = " ".join(words[i:]).strip()
    return qty, name or segment.strip()

def parse_meal_text_local(text: str) -> list[dict]:
    return [{"food_name": name, "quantity": qty}
            for seg in _segments(text)
            for qty, name in [_extract(seg)] if name]
