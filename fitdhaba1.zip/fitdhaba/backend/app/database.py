"""SQLite connection + schema."""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "fitdhaba.db"

def get_db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db() -> None:
    with get_db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS profile(
            user_id TEXT PRIMARY KEY, age INT, gender TEXT, weight REAL, height REAL,
            activity TEXT, goal TEXT, condition TEXT,
            target_cal REAL, target_protein REAL, target_carb REAL, target_fat REAL,
            target_sodium REAL, target_calcium REAL, target_iron REAL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, food_id INT, food_name TEXT,
            qty REAL, meal TEXT, calories REAL, protein REAL, carbs REAL, fat REAL,
            fiber REAL, sodium REAL, calcium REAL, iron REAL, logged_at TEXT)""")
