"""Load the Indian home-cooked + packaged food CSVs into one in-memory food DB."""
import csv
import difflib
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[3]  # c:\coding

def _to_food(fid, name, cal, carb, prot, fat, fiber, sodium, calcium, iron, source):
    try:
        cal = float(cal or 0)
    except ValueError:
        cal = 0
    if cal <= 0:
        return None
    food = dict(id=fid, name=name.strip(), calories=cal, source=source)
    for key, val in dict(carbs=carb, protein=prot, fat=fat, fiber=fiber,
                          sodium=sodium, calcium=calcium, iron=iron).items():
        try:
            food[key] = round(float(val or 0), 2)
        except ValueError:
            food[key] = 0.0
    return food

def load_foods() -> list[dict]:
    foods, fid = [], 1

    with open(DATA_DIR / "Indian_Food_Nutrition_Processed.csv", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            food = _to_food(fid, r["Dish Name"], r["Calories (kcal)"], r["Carbohydrates (g)"],
                             r["Protein (g)"], r["Fats (g)"], r["Fibre (g)"], r["Sodium (mg)"],
                             r["Calcium (mg)"], r["Iron (mg)"], "Home-cooked")
            if food:
                foods.append(food)
                fid += 1

    with open(DATA_DIR / "packaged_foods_india.csv", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            food = _to_food(fid, r["Item name"], r["Calories_kcal"], r["Carbohydrates_g"],
                             r["Proteins_g"], r["Total_Fat_g"], r["Dietary_Fiber_g"],
                             r["Sodium_mg"], r["Calcium_mg"], r["Iron_mg"], "Packaged")
            if food:
                foods.append(food)
                fid += 1

    return foods

FOODS = load_foods()
FOODS_BY_ID = {f["id"]: f for f in FOODS}
_NAMES = [f["name"] for f in FOODS]
_BY_NAME = {f["name"]: f for f in FOODS}

def find_matches(name: str, limit: int = 3) -> list[dict]:
    """Best-effort match of a free-text food name against the DB: substring (incl. naive
    singular/plural forms) first, then fuzzy."""
    name_l = name.lower().strip()
    variants = {name_l}
    if name_l.endswith("ies"):
        variants.add(name_l[:-3] + "y")
    elif name_l.endswith("es"):
        variants.add(name_l[:-2])
    elif name_l.endswith("s"):
        variants.add(name_l[:-1])
    for variant in variants:
        substr = [f for f in FOODS if variant in f["name"].lower()]
        if substr:
            substr.sort(key=lambda f: len(f["name"]))
            return substr[:limit]
    close = difflib.get_close_matches(name, _NAMES, n=limit, cutoff=0.4)
    return [_BY_NAME[n] for n in close]
