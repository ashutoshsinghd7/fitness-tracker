# FitDhaba

## Structure
```
backend/            FastAPI JSON API (no templating, no static serving)
  app/
    main.py          app + CORS + router registration
    database.py       SQLite connection + schema
    foods_data.py      loads both CSVs into an in-memory food DB
    nutrition.py       BMR/TDEE/macro target rules
    schemas.py         Pydantic request models
    routers/
      profile.py        POST/GET /api/profile
      foods.py           GET /api/foods
      logs.py            POST/DELETE /api/log, GET /api/today, GET /api/history
frontend/            static single-page app, calls the API over CORS
  index.html
```

## Run the backend
```
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## Run the frontend
```
cd frontend
python -m http.server 5500
```
Open http://127.0.0.1:5500. If the backend runs on a different host/port, update `API_BASE` at the top of `index.html`'s `<script>`.
